import os
import sys
from dotenv import load_dotenv
from app.core.logger.struct_logger import logger
from app.utils.SecretHelper import get_secret

class Settings:
    APP_NAME: str = "adr"
    APP_SERVICE_NAME: str = "adr-svc"

    def __init__(self):
        # Determine environment and load secrets accordingly
        self._secrets = self.load_secrets()

    def load_secrets(self):
        # Decide how to load secrets based on environment
        if self.is_dev_env:
            load_dotenv()  # Load .env file locally
            return self.load_secrets_from_env()
        else:
            return self.load_secrets_from_aws()

    def load_secrets_from_aws(self):
        try:
            secret_name = os.getenv("EksSecretName")
            secrets = get_secret(secret_name)
            logger.info("Successfully loaded secrets from AWS.")
            return secrets
        except Exception as e:
            logger.error("Failed to load secrets from AWS.", exc_info=e)
            return {}

    def load_secrets_from_env(self):
        logger.info("Loading secrets from environment variables.")
        return {
            "VALID_EMAIL_SENDER" : os.getenv("VALID_EMAIL_SENDER"),
            "MICROSOFT_AUTHORITY" : os.getenv("MICROSOFT_AUTHORITY"),
            "MICROSOFT_SCOPES" : os.getenv("MICROSOFT_SCOPES"),
            "MICROSOFT_MARK_EMAIL_READ_URL" : os.getenv("MICROSOFT_MARK_EMAIL_READ_URL"),
            "MICROSOFT_EMAIL_POOLING" : os.getenv("MICROSOFT_EMAIL_POOLING"),
            "MICROSOFT_EMAIL_BODY" : os.getenv("MICROSOFT_EMAIL_BODY"),
            "MICROSOFT_ATTACHMENT" : os.getenv("MICROSOFT_ATTACHMENT"),
            "GITLAB_URL" : os.getenv("GITLAB_URL"),
            "GITLAB_TOKEN" : os.getenv("GITLAB_TOKEN"),
            "GITLAB_REF_BRANCH_NAME" : os.getenv("GITLAB_REF_BRANCH_NAME"),
            "CLIENT_ID" : os.getenv("CLIENT_ID"),
            "CLIENT_SECRET" : os.getenv("CLIENT_SECRET"),
            "TENANT_ID" : os.getenv("TENANT_ID"),
            "USER_EMAIL" : os.getenv("USER_EMAIL"),
            "BUCKET_NAME" : os.getenv("BUCKET_NAME"),
            "DYNAMO_ABEND_TABLE_NAME" : os.getenv("DYNAMO_ABEND_TABLE_NAME"),
            "DYNAMO_AUDITLOG_TABLE_NAME" : os.getenv("DYNAMO_AUDITLOG_TABLE_NAME"),
        }
        
    @property  
    def is_dev_env(self):  
        pod_namespace = os.environ.get("POD_NAMESPACE")  
        return bool(pod_namespace)  

    @property
    def log_level(self):
        return "DEBUG" if self.is_dev_env else "INFO"

    @property
    def port(self):
        return 8002
    
    @property  
    def microsoft_authority(self):  
        return self._secrets.get('MICROSOFT_AUTHORITY')
    
    @property  
    def valid_email_senders(self)-> str:  
        return self._secrets.get("VALID_EMAIL_SENDER")

    @property  
    def microsoft_mark_email_read_url(self):  
        return self._secrets.get("MICROSOFT_MARK_EMAIL_READ_URL")
  
    @property  
    def microsoft_email_pooling(self):  
        return self._secrets.get("MICROSOFT_EMAIL_POOLING")
  
    @property  
    def microsoft_email_body(self):  
        return self._secrets.get("MICROSOFT_EMAIL_BODY")
  
    @property  
    def microsoft_attachment(self):  
        return self._secrets.get("MICROSOFT_ATTACHMENT")
    
    @property  
    def microsoft_scopes(self):  
        return self._secrets.get("MICROSOFT_SCOPES")
    
    @property  
    def gitlab_url(self):  
        return self._secrets.get("GITLAB_URL", "")  
  
    @property  
    def gitlab_token(self):  
        return self._secrets.get("GITLAB_TOKEN", "")  
  
    @property  
    def gitlab_ref_branch_name(self):  
        return self._secrets.get("GITLAB_REF_BRANCH_NAME", "")  
  
    @property  
    def client_id(self):  
        return self._secrets.get("CLIENT_ID", "")  
  
    @property  
    def client_secret(self):  
        return self._secrets.get("CLIENT_SECRET", "")
    
    @property  
    def tenant_id(self):  
        return self._secrets.get("TENANT_ID", "")
    
    @property  
    def user_email(self):  
        return self._secrets.get("USER_EMAIL", "")  
  
    @property  
    def bucket_name(self):  
        return self._secrets.get("BUCKET_NAME", "")  
  
    @property  
    def dynamo_abend_table_name(self):  
        return self._secrets.get("DYNAMO_ABEND_TABLE_NAME", "")  
  
    @property  
    def dynamo_auditlog_table_name(self):  
        return self._secrets.get("DYNAMO_AUDITLOG_TABLE_NAME", "")
    
try:
    settings = Settings()

except Exception as e:
    logger.exception("Failed to load application configuration with exception.", exc_info=e)
    sys.exit(1)
