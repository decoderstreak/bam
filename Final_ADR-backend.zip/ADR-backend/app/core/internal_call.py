import requests  
import ulid
from app.models.abend_pydantic import AbendItem  
from app.utils.GitLabHelper import call_gitlab
  
def save_abend_via_api(abend_data: dict , email_meta: dict) -> dict:  
    """  
    Function to call the internal API to save an abend record.  
  
    :param abend_data: Dictionary containing abend data  
    :return: Response containing the saved item or error  
    """  
    
    ulid_str = str(ulid.new())
    tracking_id = f"ABEND#{abend_item['jobname']}#{ulid_str}"
    
    abend_item ={
        "abendId": tracking_id,
        "incidentNumber": abend_data["incidentNumber"],
        "jobName": abend_data["jobname"],
        "abendedAt": abend_data["created"],
        "orderId": abend_data["orderId"],
        "jobenodeid":abend_data["jobenodeid"],
        "processStatus": "Abend Detected",
        "severity":abend_data["severity"],
        "serviceNowGroup":abend_data["serviceNowGroup"],
        "emailMetadata": email_meta
    }
    abend_item = AbendItem(**abend_data)
  
    response = requests.post("http://your-api-url/abends", json=abend_item.model_dump())  
  
    if response.status_code == 200:  
        call_gitlab(abend_data["jobname"],
                    abend_data["orderId"],
                    abend_data["incidentNumber"],
                    abend_data["jobenodeid"])
        return response.json()
    else:  
        response.raise_for_status()  