import boto3
from botocore.exceptions import ClientError
from app.core.logger.struct_logger import logger

def create_dynamodb_table(table_name, key_schema, attribute_definitions, provisioned_throughput, global_secondary_indexes=None):
    """
    Create a DynamoDB table if it doesn't already exist.

    :param table_name: Name of the table to create
    :param key_schema: List of key schema elements
    :param attribute_definitions: List of attribute definitions
    :param provisioned_throughput: Dictionary with Read and Write Capacity Units
    :param global_secondary_indexes: Optional list of global secondary index specifications
    :return: The newly created Table resource or existing table reference
    """
    try:
        # Create a DynamoDB client
        dynamodb = boto3.client('dynamodb')

        # Check if table exists
        existing_tables = dynamodb.list_tables()['TableNames']
        if table_name in existing_tables:
            logger.info(f"Table {table_name} already exists.")
        else:
            params = {
                'TableName': table_name,
                'KeySchema': key_schema,
                'AttributeDefinitions': attribute_definitions,
                'ProvisionedThroughput': provisioned_throughput
            }

            if global_secondary_indexes:
                params['GlobalSecondaryIndexes'] = global_secondary_indexes

            response = dynamodb.create_table(**params)
            logger.info(f"Creating table {table_name}.")
            dynamodb.get_waiter('table_exists').wait(TableName=table_name)
            logger.info(f"Table {table_name} created successfully.")
        return boto3.resource('dynamodb').Table(table_name)
    except ClientError as e:
        logger.error(f"Error creating table {table_name}: {e}")
        return None

def setup_dynamodb_tables():
    # SOP Table setup
    SOPTableName = "adr-sop-dynamodb-dev"
    SOPKeySchema = [
        {'AttributeName': 'sopId', 'KeyType': 'HASH'}
    ]

    SOPAttributeDefinitions = [
        {'AttributeName': 'sopId', 'AttributeType': 'S'},
        {'AttributeName': 'sopName', 'AttributeType': 'S'},
        {'AttributeName': 'jobName', 'AttributeType': 'S'},
        {'AttributeName': 'abendType', 'AttributeType': 'S'},
        {'AttributeName': 'incidentNumber', 'AttributeType': 'S'},
        {'AttributeName': 'createdAt', 'AttributeType': 'S'},
        {'AttributeName': 'updatedAt', 'AttributeType': 'S'},
        {'AttributeName': 'createdBy', 'AttributeType': 'S'},
        {'AttributeName': 'updatedBy', 'AttributeType': 'S'},
        {'AttributeName': 'generation', 'AttributeType': 'N'}
    ]

    SOPThroughput = {'ReadCapacityUnits': 5, 'WriteCapacityUnits': 5}

    SOPTable = create_dynamodb_table(
        table_name=SOPTableName,
        key_schema=SOPKeySchema,
        attribute_definitions=SOPAttributeDefinitions,
        provisioned_throughput=SOPThroughput
    )

    # Abend Table setup
    AbendTableName = "adr-abend-dynamodb-dev"
    AbendKeySchema = [
        {'AttributeName': 'trackingID', 'KeyType': 'HASH'},
        {'AttributeName': 'abendedAt', 'KeyType': 'RANGE'}
    ]

    AbendAttributeDefinitions = [
        {'AttributeName': 'trackingID', 'AttributeType': 'S'},
        {'AttributeName': 'abendedAt', 'AttributeType': 'S'},
        {'AttributeName': 'abendType', 'AttributeType': 'S'},
        {'AttributeName': 'jobName', 'AttributeType': 'S'},
        {'AttributeName': 'domainArea', 'AttributeType': 'S'},
        {'AttributeName': 'abendActionStatus', 'AttributeType': 'S'}
    ]

    AbendThroughput = {'ReadCapacityUnits': 5, 'WriteCapacityUnits': 5}

    AbendGlobalSecondaryIndexes = [
        {
            'IndexName': 'AbendTypeIndex',
            'KeySchema': [
                {'AttributeName': 'abendType', 'KeyType': 'HASH'},
                {'AttributeName': 'abendedAt', 'KeyType': 'RANGE'}
            ],
            'Projection': {'ProjectionType': 'ALL'},
            'ProvisionedThroughput': {'ReadCapacityUnits': 5, 'WriteCapacityUnits': 5}
        },
        {
            'IndexName': 'JobNameIndex',
            'KeySchema': [
                {'AttributeName': 'jobName', 'KeyType': 'HASH'},
                {'AttributeName': 'abendedAt', 'KeyType': 'RANGE'}
            ],
            'Projection': {'ProjectionType': 'ALL'},
            'ProvisionedThroughput': {'ReadCapacityUnits': 5, 'WriteCapacityUnits': 5}
        },
        {
            'IndexName': 'DomainAreaIndex',
            'KeySchema': [
                {'AttributeName': 'domainArea', 'KeyType': 'HASH'},
                {'AttributeName': 'abendedAt', 'KeyType': 'RANGE'}
            ],
            'Projection': {'ProjectionType': 'ALL'},
            'ProvisionedThroughput': {'ReadCapacityUnits': 5, 'WriteCapacityUnits': 5}
        },
        {
            'IndexName': 'AbendActionStatusIndex',
            'KeySchema': [
                {'AttributeName': 'abendActionStatus', 'KeyType': 'HASH'},
                {'AttributeName': 'abendedAt', 'KeyType': 'RANGE'}
            ],
            'Projection': {'ProjectionType': 'ALL'},
            'ProvisionedThroughput': {'ReadCapacityUnits': 5, 'WriteCapacityUnits': 5}
        },
    ]

    AbendTable = create_dynamodb_table(
        table_name=AbendTableName,
        key_schema=AbendKeySchema,
        attribute_definitions=AbendAttributeDefinitions,
        provisioned_throughput=AbendThroughput,
        global_secondary_indexes=AbendGlobalSecondaryIndexes
    )

    # Audit Log Table setup
    AuditTableName = "adr-auditlog-dynamodb-dev"
    AuditKeySchema = [
        {'AttributeName': 'trackingId', 'KeyType': 'HASH'}
    ]

    AuditAttributeDefinitions = [
        {'AttributeName': 'trackingId', 'AttributeType': 'S'},
        {'AttributeName': 'status', 'AttributeType': 'S'},
        {'AttributeName': 'level', 'AttributeType': 'S'},
        {'AttributeName': 'description', 'AttributeType': 'S'},
        {'AttributeName': 'timestamp', 'AttributeType': 'S'}
    ]

    AuditThroughput = {'ReadCapacityUnits': 5, 'WriteCapacityUnits': 10}

    AuditTable = create_dynamodb_table(
        table_name=AuditTableName,
        key_schema=AuditKeySchema,
        attribute_definitions=AuditAttributeDefinitions,
        provisioned_throughput=AuditThroughput
    )

if __name__ == "__main__":
    setup_dynamodb_tables()
