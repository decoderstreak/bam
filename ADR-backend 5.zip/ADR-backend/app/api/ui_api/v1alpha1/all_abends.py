from fastapi import APIRouter, HTTPException, Query, Path
from typing import Optional, List
from app.models.abend_pydantic import AbendItem
from app.core.abends import DynamoDBAbend , AbendMetrics

router = APIRouter()

@router.get(
    "/cards",
    summary="Get ABEND summary metrics",
    description="Returns counts of total ABENDs, detected (non-resolved), resolved jobs, and assignments to AI or humans.",
)
async def get_abend_summary():
    try:
        abend_metrics = AbendMetrics(table_name="adr-abend-dynamodb-dev")
        total_abends = await abend_metrics.get_total_abends_count()
        abend_detected = await abend_metrics.count_abends_non_resolved()
        resolved = await abend_metrics.count_abends_by_job_status()
        ai_assigned = await abend_metrics.count_abends_assigned_to_ai()
        human_assigned = await abend_metrics.count_abends_assigned_to_humans()

        return {
            "total_abends": total_abends,
            "abend_detected": abend_detected,
            "resolved": resolved,
            "ai_assigned": ai_assigned,
            "human_assigned": human_assigned
        }
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to fetch abend summary: {str(e)}"
        )


@router.get("/abends", response_model=List[AbendItem])
async def list_abends(
    limit: int = Query(..., ge=5, le=100),
    nextPageToken: Optional[str] = None,
    jobStatus: Optional[str] = None,
    domainArea: Optional[str] = None,
    severity: Optional[str] = None,
    abendedAt: Optional[str] = None,
    search: Optional[str] = None
):
    try:
        dynamo_abend = DynamoDBAbend(table_name="adr-abend-dynamodb-dev")
        abends = await dynamo_abend.list_abends(
            limit=limit,
            nextPageToken=nextPageToken,
            jobStatus=jobStatus,
            domainArea=domainArea,
            severity=severity,
            abendedAt=abendedAt,
            search=search
        )
        return abends
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail={
                "code": "INTERNAL_ERROR",
                "message": "Failed to fetch abends",
                "details": str(e),
            }
        )

@router.get("/abends/tracking/{tracking_id}", response_model=AbendItem)
async def get_abend_details_by_tracking_id(tracking_id: str):
    try:
        dynamo_abend = DynamoDBAbend(table_name="adr-abend-dynamodb-dev")
        abend = await dynamo_abend.get_abend_record(tracking_id)
        if not abend:
            raise HTTPException(
                status_code=404,
                detail=f"No abend found for tracking ID: {tracking_id}"
            )
        return AbendItem(**abend)
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail={
                "code": "INTERNAL_ERROR",
                "message": "Failed to fetch abend",
                "details": str(e),
            }
        )
