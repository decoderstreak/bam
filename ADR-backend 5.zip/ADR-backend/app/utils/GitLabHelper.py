import requests
from datetime import datetime, timezone
from app.core.logger.struct_logger import logger  
from app.utils.DynamoDBHelper import insert_into_dynamodb
from app.models.auditlog_pydantic import AuditLog
from app.core.abends import DynamoDBAbend
from app.core.config import settings

def call_gitlab(jobname, orderid, incnum, jobnodeid, tracking_id):
    trigger_content = f"{jobname},{orderid},{incnum},{jobnodeid}"
    
    # Extract settings once
    gitlab_token = settings.gitlab_token
    gitlab_ref_branch_name = settings.gitlab_ref_branch_name
    gitlab_url = settings.gitlab_url

    data = {
        'token': gitlab_token,
        'ref': gitlab_ref_branch_name,
        'variables[TRIGGER_CONTENT]': trigger_content
    }

    def create_audit_log(tracking_id, status, level, description):
        audit_log_entry = {
            "trackingId": tracking_id,
            "status": status,
            "level": level,
            "description": description,
            "details": {
                "jobRunId": jobname,
                "retries": 0
            },
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        audit_log = AuditLog(**audit_log_entry)
        insert_into_dynamodb("adr-auditlog-dynamodb-dev", audit_log.model_dump())

    try:
        response = requests.post(gitlab_url, data=data, verify=False)
        
        if response.ok:
            dynamo_abend = DynamoDBAbend(table_name="adr-abend-dynamodb-dev")
            dynamo_abend.update_abend_record(tracking_id, "LOG_EXTRACTION_INITIATED")
            
            create_audit_log(tracking_id, "LOG_EXTRACTION_INITIATED", "INFO", "Log extraction job triggered")
            logger.info("Pipeline triggered successfully with file content as a variable!")
        else:
            create_audit_log(tracking_id, "LOG_EXTRACTION_ERROR", "ERROR", "Log extraction job failed")
            logger.error(f"Trigger failed: {response.status_code} - {response.text}")
    except requests.exceptions.RequestException as e:
        logger.exception(f"An error occurred while triggering the pipeline: {e}")

