import boto3
from botocore.exceptions import ClientError
from app.core.logger.struct_logger import logger

def create_dynamodb_table(table_name, key_schema, attribute_definitions, provisioned_throughput):
    """
    Create a DynamoDB table if it doesn't already exist.

    :param table_name: Name of the table to create
    :param key_schema: List of key schema elements
    :param attribute_definitions: List of attribute definitions
    :param provisioned_throughput: Dictionary with Read and Write Capacity Units
    :return: The newly created Table resource or existing table reference
    """
    try:
        # Create a DynamoDB client
        dynamodb = boto3.client('dynamodb')

        # Check if table exists
        existing_tables = dynamodb.list_tables()['TableNames']
        if table_name in existing_tables:
            logger.info(f"Table {table_name} already exists.")
        else:
            response = dynamodb.create_table(
                TableName=table_name,
                KeySchema=key_schema,
                AttributeDefinitions=attribute_definitions,
                ProvisionedThroughput=provisioned_throughput
            )
            logger.info(f"Creating table {table_name}.")
            dynamodb.get_waiter('table_exists').wait(TableName=table_name)
            logger.info(f"Table {table_name} created successfully.")
        return boto3.resource('dynamodb').Table(table_name)
    except ClientError as e:
        logger.info(f"Error creating table: {e}")
        return None

def insert_into_dynamodb(table_name, item):
    """
    Inserts an item into the specified DynamoDB table.

    :param table_name: Name of the table
    :param item: Dictionary containing item data
    :return: Response from DynamoDB
    """
    try:
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table(table_name)

        response = table.put_item(Item=item)
        logger.info(f"Item inserted into {table_name}", response=response)
        return response

    except ClientError as e:
        logger.error(f"Error inserting item into {table_name}: {e}")
        return None

def query_dynamodb_by_index(table_name, index_name, key_condition_expression, expression_attribute_values):
    """
    Queries items from the specified DynamoDB table using a global secondary index.

    :param table_name: Name of the table
    :param index_name: Name of the global secondary index
    :param key_condition_expression: Key condition expression for the query
    :param expression_attribute_values: Values for the expression attributes
    :return: List of items matching the query
    """
    try:
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table(table_name)

        response = table.query(
            IndexName=index_name,
            KeyConditionExpression=key_condition_expression,
            ExpressionAttributeValues=expression_attribute_values
        )
        items = response.get('Items', [])
        logger.info(f"Query successful on {table_name}.{index_name}", item_count=len(items))
        return items

    except ClientError as e:
        logger.error(f"Error querying {table_name}.{index_name}: {e}")
        return []
    
def update_dynamodb_item(table_name, key, update_expression, expression_attribute_values, expression_attribute_names=None):
    """
    Updates an item in the specified DynamoDB table.

    :param table_name: Name of the table
    :param key: Dictionary with key of the item to update
    :param update_expression: Update expression defining the attributes that should be modified
    :param expression_attribute_values: Values for placeholders in the update expression
    :param expression_attribute_names: Optional. Names for placeholders in the update expression
    :return: Response from DynamoDB
    """
    try:
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table(table_name)

        # Build the update parameters
        update_params = {
            'Key': key,
            'UpdateExpression': update_expression,
            'ExpressionAttributeValues': expression_attribute_values
        }
        
        if expression_attribute_names:
            update_params['ExpressionAttributeNames'] = expression_attribute_names

        response = table.update_item(**update_params)
        logger.info("Item updated successfully", response=response)
        return response

    except ClientError as e:
        logger.error(f"Error updating item in {table_name}: {e}")
        return None