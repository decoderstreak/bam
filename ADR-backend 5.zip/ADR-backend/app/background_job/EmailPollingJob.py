import re
import time
import threading
from datetime import datetime
import msal
import base64
import aiohttp
import asyncio
from app.utils.AwsHelper import AWSS3Helper
from app.core.logger.struct_logger import logger
from app.core.internal_call import save_abend_via_api
from app.core.config import settings


def get_token():
    try:
        authority = settings.microsoft_authority.format(settings.tenant_id)
        logger.info("Authority URL constructed", authority=authority)

        app = msal.ConfidentialClientApplication(
            settings.client_id , authority=authority, client_credential=settings.client_secret)
        logger.info("MSAL Confidential Client Application initialized")

        token_response = app.acquire_token_for_client(scopes=[settings.microsoft_scopes])
        logger.info("Acquired token response", token_response=token_response)

        access_token = token_response.get("access_token")
        if not access_token:
            logger.error("Failed to acquire access token", error=token_response.get(
                "error_description", "No error description available"))
            raise ValueError("Failed to acquire access token.")

        logger.info("Successfully acquired access token")
        return access_token

    except msal.AuthError as auth_error:
        logger.exception("Authentication error occurred.", error=str(auth_error))
        raise  # Re-raise or handle specifically as needed

    except Exception as e:
        logger.exception("An unexpected error occurred when acquiring the token.", error=str(e))
        raise  # Re-raise or handle specifically as needed

async def mark_email_as_read(message_id, token):
    """Marks an email as read by updating its status via Microsoft Graph API."""
    try:
        url = settings.microsoft_mark_email_read_url.format(settings.user_email, message_id=message_id)
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }
        data = {"isRead": True}
        
        async with aiohttp.ClientSession() as session:
            async with session.patch(url, headers=headers, json=data) as response:
                response.raise_for_status()  # Raise an error for bad responses
                logger.info("Email marked as read", message_id=message_id)
                
    except aiohttp.ClientError as e:
        logger.error("Failed to mark email as read", message_id=message_id, error=str(e))

def is_valid_sender(sender):
    """
    Checks if the sender's email address matches any valid sender patterns.
    
    :param sender: Email address of the sender
    :return: Boolean indicating whether the sender is valid
    """
    valid_senders = settings.valid_email_senders
    valid_senders = {email.strip() for email in valid_senders.split(",") if email}
    return sender in valid_senders

def timeformat(date_str):
    """
    Formats a date string from 'YYYYMMDDHHMMSS' to 'YYYY-MM-DD HH:MM:SS'.
    
    :param date_str: Date string in 'YYYYMMDDHHMMSS' format
    :return: Formatted date string
    """
    parsed_date = datetime.strptime(date_str[:8], "%Y%m%d")
    time_part = f"{date_str[8:10]}:{date_str[10:12]}:{date_str[12:14]}"
    formatted = f"{parsed_date.strftime('%Y-%m-%d')} {time_part}"
    return formatted

def extract_fields(body):
    """
    Extracts predefined fields from the email body using regular expressions.
    
    :param body: The body text of the email
    :return: Dictionary of extracted fields
    """
    try:
        incident_match = re.search(r"Incident Number[:\s]*([A-Z0-9\-]+)", body)
        jobname_match = re.search(r"JOB NAME[:\s]*([A-Za-z0-9_\-]+)", body)
        orderid_match = re.search(r"ORDER ID[:\s]*([A-Z0-9\-]+)", body)
        jobnodeid_match = re.search(r"JOB NODE ID[:\s]*([A-Z0-9\-]+)", body)
        created_match1 = re.search(r"ALERT TRAP TIME:\s*(\d{14})", body)
        created_match = timeformat(created_match1.group(1)) if created_match1 else None
        severity_match = re.search(r"Priority[:\s]*\d+\s*-\s*(.+)", body)
        servicenowgrp_match = re.search(r"Members of group\s*(.+)", body)
        
        fields = {
            "incidentNumber": incident_match.group(1) if incident_match else None,
            "jobname": jobname_match.group(1) if jobname_match else None,
            "orderId": orderid_match.group(1) if orderid_match else None,
            "jobenodeid": jobnodeid_match.group(1) if jobnodeid_match else None,
            "severity": severity_match.group(1) if severity_match else None,
            "created": created_match,
            "serviceNowGroup": servicenowgrp_match.group(1).strip().rstrip(",") if servicenowgrp_match else None,
        }
        
        logger.debug("Extracted fields from email body", fields=fields)
        return fields

    except Exception as e:
        logger.error("Error extracting fields from email body", error=str(e))
        return {}

def validate_fields(fields):
    """
    Validates if all required fields are present and contain values.
    
    :param fields: Dictionary containing email fields
    :return: Boolean indicating validity of the fields
    """
    return all(fields.values()) and "jobname" in fields

async def email_polling_async(token):
    """
    Polls for unread emails, extracts relevant fields, and marks them as read if valid.
    
    :param token: OAuth token used for authorization with Microsoft Graph API
    """
    try:
        headers = {
            "Authorization": f"Bearer {token}"
        }
        url = settings.microsoft_email_pooling.format(settings.user_email)
        
        async with aiohttp.ClientSession() as session:
            async with session.get(url, headers=headers) as response:
                response.raise_for_status()
                
                emails = await response.json()
                email_list = emails.get("value", [])
                logger.info("Email polling successful", email_count=len(email_list))
                
                for email in email_list:
                    subject = email.get("subject", "")
                    message_id = email["id"]
                    
                    if "INC" in subject:
                        sender = email["from"]["emailAddress"]["address"]
                        if not is_valid_sender(sender):
                            logger.warning("Invalid sender encountered", sender=sender)
                            continue
                        
                        body_url = settings.microsoft_email_body.format(settings.user_email, message_id=message_id)
                        
                        async with session.get(body_url, headers=headers) as body_response:
                            body_response.raise_for_status()

                            body_text = await body_response.text()
                            fields = extract_fields(body_text)

                            if not validate_fields(fields):
                                logger.warning("Missing required fields in email", message_id=message_id)
                                continue 

                            if all(fields.values()):
                                email_meta = {
                                    "subject": subject,
                                    "from": sender,
                                    "to": email["toRecipients"][0]["emailAddress"]["address"] if email.get("toRecipients") else None,
                                    "sentDateTime": email.get("sentDateTime"),
                                    "receivedDateTime": email.get("receivedDateTime"),
                                    "isRead": email.get("isRead"),
                                    "conversationID": email.get("conversationId")
                                }
                                save_resp = save_abend_via_api(fields,email_meta)
                                logger.info("After inserting into table", save_resp)

                    elif "CMOD" in subject or "FAULT LOG REPOR" in subject:
                        attachments_url =settings.microsoft_attachment.format(settings.user_email, message_id=message_id)
                        
                        async with session.get(attachments_url, headers=headers) as attachments_response:
                            attachments_response.raise_for_status()

                            attachments = await attachments_response.json().get("value", [])
                            for attachment in attachments:
                                if attachment.get("@odata.type") == "#microsoft.graph.fileAttachment":
                                    file_name = attachment.get("name")
                                    if file_name and file_name.lower().endswith(".txt"):
                                        file_content = base64.b64decode(attachment.get("contentBytes", ""))
                                        
                                        AWSS3Helper.upload_fileobj_to_s3(file_content, settings.bucket_name , file_name)
                                        logger.info(f"Uploaded {file_name} to S3")
                                    else:
                                        logger.info(f"Skipped {file_name} (not a .txt file or missing)")

                    await mark_email_as_read(message_id, token)
                    
    except aiohttp.ClientError as e:
        logger.error("Error during email polling", error=str(e))


def polling_thread():
    """Function to run polling in a separate background thread."""
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    
    while True:
        token = get_token()
        loop.run_until_complete(email_polling_async(token))
        time.sleep(60)

if __name__ == "__main__":
    print("Starting email polling in a separate thread...")
    poll_thread = threading.Thread(target=polling_thread, daemon=True)
    poll_thread.start()
    
    while True:
        time.sleep(1)
