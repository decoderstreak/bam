from typing import List, Optional
from pydantic import BaseModel

class SOPItem(BaseModel):
    sopID: str
    sopName: str
    jobName: str
    abendType: List[str]
    url: str
    generation: int
    uploadedAt: str
    createdAt: str
    updatedAt: str
    createdBy: str
    updatedBy: str

class Pagination(BaseModel):
    next: Optional[str]
    hasMore: bool
    limit: int

class SOPListResponse(BaseModel):
    sops: List[SOPItem]
    pagination: Pagination
