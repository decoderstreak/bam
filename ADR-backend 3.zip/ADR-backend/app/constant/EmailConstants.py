ValidEmailSender = {"Vivek.Raj2@elevancehealth.com",
                    "UmanTabassum.Mohammad2@elevancehealth.com",
                    'elevance.health.servicenow@elevancehealth.com'}

MicrosoftAuthority = "https://login.microsoftonline.com/{TENANT_ID}"
MicrosoftScopes = ["https://graph.microsoft.com/.default"]
MicrosoftMarkEmailReadUrl = "https://graph.microsoft.com/v1.0/users/{USER_EMAIL}/messages/{message_id}"
MicrosoftEmailPooling = "https://graph.microsoft.com/v1.0/users/{USER_EMAIL}/mailFolders('Inbox')/messages?$filter=isRead eq false"
MicrosoftEmailBody = "https://graph.microsoft.com/v1.0/users/{USER_EMAIL}/messages/{message_id}/$value"
MicrosoftAttachment = "https://graph.microsoft.com/v1.0/users/{USER_EMAIL}/messages/{message_id}/attachments"

#GITLAB constant
GitlabUrl = "https://gitlab.gitlab-dev.apps.caas01-ocp4-np1-eastus.ocpazure.internal.das/api/v4/projects/10272/trigger/pipeline"
GitlabToken = "glptt-c39b5e7a9b14966f70577f1b6bc1b0bfe3ffe6cc"
GitlabRefBranchName = "main"