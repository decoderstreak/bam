EksSecretName = ""

CLIENT_ID = 'b644d0d8-fc95-4365-8049-555acd10b798'
CLIENT_SECRET = '6Fs8Q~sJDE~n9LU5dIJ~ajNn-kVOZ46fGvsB7do5'
TENANT_ID = 'df0509ec-b76f-45a7-936b-c8a3357221c8'
USER_EMAIL = 'AutomatedDiagnosisandRemediation@anthem-Dev.com' 
DYNAMO_TABLE_NAME = "adr-dynamodb-dev"

BUCKET_NAME='arn:aws:s3:::adr-abend-log-in-dev'  