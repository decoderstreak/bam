from fastapi import APIRouter, HTTPException, Body
from datetime import datetime, timezone
from app.models.abend_pydantic import AbendItem
from app.models.auditlog_pydantic import AuditLog
from app.core.abends import DynamoDBAbend
from app.utils.DynamoDBHelper import insert_into_dynamodb

router = APIRouter()

@router.post("/abends", response_model=AbendItem)
def create_abend(abend: AbendItem = Body(...)):
    """
    Endpoint to create an abend record in DynamoDB.

    :param abend: AbendItem model data
    :return: Saved abend item
    """
    try:
        dynamo_abend = DynamoDBAbend(table_name="adr-abend-dynamodb-dev")
        if dynamo_abend.save_abend_record(abend.model_dump()):
            # Update the processStatus to ABEND_REGISTERED
            dynamo_abend.update_abend_record(abend.trackingID, "ABEND_REGISTERED")
            
            # Create an audit log entry
            audit_log_entry = {
                "trackingId": abend.trackingID,
                "status": "ABEND_REGISTERED",
                "level": "INFO",
                "description": "Abend notification received and processed",
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
            audit_log = AuditLog(**audit_log_entry)
            insert_into_dynamodb("your-audit-log-table-name", audit_log.model_dump())
            
            return abend
        else:
            raise HTTPException(
                status_code=500,
                detail={
                    "code": "INTERNAL_ERROR",
                    "message": "Failed to save abend record",
                }
            )
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail={
                "code": "INTERNAL_ERROR",
                "message": "Failed to save abend record",
                "details": str(e),
            }
        )
