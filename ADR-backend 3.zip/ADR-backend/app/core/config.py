import os
import sys
from app.core.logger.struct_logger import logger
from app.utils.SecretHelper import get_secret
from app.constant.AppConstants import EksSecretName


class Settings:
    APP_NAME: str = "adr"
    APP_SERVICE_NAME: str = "adr-svc"

    def __init__(self):
        # Load secrets during initialization
        self._secrets = self.load_secrets()

    def load_secrets(self):
        # Define the name of the secret in AWS Secrets Manager
        secret_name = EksSecretName
        return get_secret(secret_name)

    @property
    def is_dev_env(self):
        pod_namespace = os.environ.get("POD_NAMESPACE")
        return bool(pod_namespace)

    @property
    def secret_loader(self):
        return self._secrets

    @property
    def log_level(self):
        if self.is_dev_env:
            return "DEBUG"
        return "INFO"

    @property
    def port(self):
        return 8000

try:
    settings = Settings()

except Exception:
    logger.exception(
        "Failed to load application configuration with exception. Exiting."
    )
    sys.exit(1)
