"""
This module provides a helper class, `AWSS3Helper`, containing various static methods for managing
files in Amazon S3. It includes functionality for uploading both local files and file-like objects to S3,
downloading files and file-like objects from S3, and handling operations such as moving, copying and deleting S3 objects.
"""

import boto3
import logging
from botocore.exceptions import NoCredentialsError

logger = logging.getLogger(__name__)


class AWSS3Helper:
    """
    This is helper class for uploading both local files and file-like objects to S3,
    downloading files and file-like objects from S3, and handling operations such as moving, copying and deleting S3 objects.

    """
    @staticmethod
    def get_s3_client():
        """
        Returns an S3 client using credentials from the configuration.

        Returns:
            boto3.client: A Boto3 S3 client.
        """
        return boto3.client(
            's3',
            region_name = "AWS_REGION",
            aws_access_key_id = "AWSAccessKey",
            aws_secret_access_key = "AWSSecretKey"
        )
        
    @staticmethod
    def get_s3_cred():
        aws_access_key_id = "AWSAccessKey",
        aws_secret_access_key = "AWSSecretKey"
        credentials = boto3.Session(aws_access_key_id, aws_secret_access_key).get_credentials()
        
        return credentials

    
    @staticmethod
    def upload_file_to_s3(local_file_path, bucket_name, s3_file_path):
        """
        Upload a local file to S3.

        :param local_file_path: Path to the local file.
        :param bucket_name: Name of the S3 bucket.
        :param s3_file_path: Path in the S3 bucket where the file will be stored.
        """
        logger.info("Uploading file to s3")
        try:
            s3_client =  boto3.client('s3')
            s3_client.upload_file(local_file_path, bucket_name, s3_file_path)
            logger.info(
                f"File uploaded successfully to S3:{s3_file_path}"
            )
        except Exception as error:
            logger.error(f"Error occurred while upload_file_to_s3 with message {str(error)}")

    @staticmethod
    def upload_fileobj_to_s3(file_obj, bucket_name, s3_file_path):
        """
        Upload a file to S3 from an in-memory file-like object.

        :param file_obj: A file-like object.
        :param bucket_name: S3 bucket name.
        :param s3_file_path: Path in the bucket where the file will be stored.
        """
        logger.info("Uploading file object to s3")
        try:
            s3_client =  boto3.client('s3')
            s3_client.upload_fileobj(file_obj, bucket_name, s3_file_path)
            logger.info(
                f"File object uploaded successfully to S3: {s3_file_path}"
            )
        except Exception as error:
            logger.error(f"Failed to upload file object to S3 {str(error)}")

    @staticmethod
    def copy_file_object(
        source_bucket_name,
        destination_bucket_name,
        source_file_key,
        target_file_key,
        delete_original=False,
    ):
        """
        Copy a file object from one S3 bucket to another.

        :param source_bucket_name: Name of the source S3 bucket.
        :param destination_bucket_name: Name of the destination S3 bucket.
        :param source_file_key: Key of the source file.
        :param target_file_key: Key of the target file.
        :param delete_original: Whether to delete the original file after copying.
        """
        try:
            s3 = AWSS3Helper.get_s3_client()
            copy_source = {"Bucket": source_bucket_name, "Key": source_file_key}
            s3.copy_object(
                Bucket=destination_bucket_name,
                CopySource=copy_source,
                Key=target_file_key,
            )

            if delete_original:
                s3.delete_object(Bucket=source_bucket_name, Key=source_file_key)
                logger.info(
                    f"Object {source_file_key} successfully deleted from {source_bucket_name}."
                )

            logger.info(
                f"Object {source_file_key} successfully copied from {source_bucket_name} to {destination_bucket_name}/{target_file_key}."
            )
        except Exception as error:
            logger.error(
                f"Error moving file {source_file_key} from {source_bucket_name} to {destination_bucket_name}: {str(error)}"
            )

    @staticmethod
    def delete_file_from_s3(bucket_name, file_path):
        """
        Delete a specified file from an S3 bucket.

        :param bucket_name: Name of the S3 bucket.
        :param file_path: Path of the file to delete.
        """
        s3 = AWSS3Helper.get_s3_client()
        try:
            s3.delete_object(Bucket=bucket_name, Key=file_path)
            logger.info(f"Deleted {file_path} from bucket")
        except Exception as error:
            logger.error(f"An error occurred in delete file from s3: {str(error)}")
            
    @staticmethod
    def download_file_from_s3(bucket_name, s3_file_path, local_file_path):
        """
        Download a file from S3 to a local path.

        :param bucket_name: Name of the S3 bucket.
        :param s3_file_path: Path in the S3 bucket where the file is stored.
        :param local_file_path: Path where the file will be saved locally.
        """
        logger.info("Downloading file from s3")
        try:
            s3_client = AWSS3Helper.get_s3_client()
            s3_client.download_file(bucket_name, s3_file_path, local_file_path)
            logger.info(
                f"File downloaded successfully from S3: {s3_file_path} to {local_file_path}"
            )
            return local_file_path
        except Exception as error:
            logger.error(f"Error occurred while download_file_from_s3 with message {str(error)}")
            raise 

    @staticmethod
    def download_fileobj_from_s3(bucket_name, s3_file_path, file_obj):
        """
        Download a file from S3 to an in-memory file-like object.

        :param bucket_name: Name of the S3 bucket.
        :param s3_file_path: Path in the S3 bucket where the file is stored.
        :param file_obj: A file-like object where the file will be written.
        """
        logger.info("Downloading file object from s3")
        try:
            s3_client = AWSS3Helper.get_s3_client()
            s3_client.download_fileobj(bucket_name, s3_file_path, file_obj)
            logger.info(
                f"File object downloaded successfully from S3: {s3_file_path}"
            ) 
            return file_obj
        except Exception as error:
            logger.error(f"Failed to download file object from S3 {str(error)}")
            
            
    @staticmethod
    def generate_presigned_url(s3_file_path, bucket_name, expiration=3600):
        """
        Generates a presigned URL for accessing an S3 object.

        Args:
            s3_file_path (str): The S3 file path.
            bucket_name (str): The name of the S3 bucket.
            expiration (int, optional): Time in seconds for the presigned URL to remain valid. Defaults to 3600.

        Returns:
            str: The presigned URL.
        """
        
        try:
            logger.info("In generate_presigned_url Function")
            logger.debug(f"Received params s3_file_path:{s3_file_path}")
            s3_client = AWSS3Helper.get_s3_client()
            
            # Generate a pre-signed URL for the S3 object
            file_type = s3_file_path.split("/")[-1].split(".")[-1]
            if file_type == 'pdf':
                response_content_type = 'application/pdf'
            elif file_type == 'docx':
                response_content_type = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
            elif file_type == 'pptx':
                response_content_type = 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
            elif file_type == 'txt':
                response_content_type = 'text/plain'
            elif file_type in ['jpg', 'jpeg']:
                response_content_type = 'image/jpeg'
            elif file_type == 'png':
                response_content_type = 'image/png'
            else:
                response_content_type = ''

            if response_content_type == '':
                params = {'Bucket': bucket_name, 'Key': s3_file_path, 'ResponseContentDisposition': 'inline',}
            else:
                params = {'Bucket': bucket_name, 'Key': s3_file_path, 'ResponseContentDisposition': 'inline', 'ResponseContentType': response_content_type}
            
            presigned_url = s3_client.generate_presigned_url(
                'get_object',
                Params = params,
                ExpiresIn = expiration
            )
            logger.debug("In generate_presigned_url Function presigned_url:%s", presigned_url)
            return presigned_url
        except NoCredentialsError:
            logger.error("Credentials not available")
            return None
