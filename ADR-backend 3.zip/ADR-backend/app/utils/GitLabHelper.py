import requests
from app.constant.EmailConstants import GitlabUrl, GitlabToken, GitlabRefBranchName
from app.core.logger.struct_logger import logger


def call_gitlab(jobname, orderid, incnum, jobnodeid):  
    trigger_content = f"{jobname},{orderid},{incnum},{jobnodeid}"  
    data = {  
        'token': GitlabToken,  
        'ref': GitlabRefBranchName,  
        'variables[TRIGGER_CONTENT]': trigger_content  
    }  
    try:  
        response = requests.post(GitlabUrl, data=data, verify=False)  
        if response.ok:  
            logger.info("Pipeline triggered successfully with file content as a variable!")  
        else:  
            logger.error(f"Trigger failed: {response.status_code} - {response.text}")  
    except requests.exceptions.RequestException as e:  
        logger.exception(f"An error occurred while triggering the pipeline: {e}")  
