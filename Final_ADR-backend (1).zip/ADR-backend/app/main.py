from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
import uvicorn
from app.api.ui_api.v1alpha1.all_abends import router as abend_router
from app.api.internal_api.v1alpha1.abend import router as abend_post_router
from app.core.config import settings

app = FastAPI()  

# Determine allow_origins dynamically 
if settings.environment == "dev":
    allow_origins = ["http://localhost:3000"]
else:
    allow_origins = ["https://adrportal-dev.elevancehealth.com"]

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=allow_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register the API routers
app.include_router(abend_router, prefix="/ui_api/v1alpha1", tags=["Abends"])
app.include_router(abend_post_router, prefix="/internal_api/v1alpha1", tags=["Abend Creation"])

# Define homepage
@app.get("/", response_class=HTMLResponse)
def homepage():
    html_content = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>Abends Dashboard</title>
        <style>
            body { font-family: Arial; background-color: #f4f4f4; padding: 2em; }
            .container { background: white; padding: 2em; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
            h1 { color: #333; }
            a { color: #007acc; text-decoration: none; }
            a:hover { text-decoration: underline; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Welcome to the Abends Monitoring System</h1>
            <p>Use <a href="/docs">Swagger UI</a> to explore the API endpoints.</p>
            <p>Or <a href="/redoc">ReDoc</a> for a more structured API reference.</p>
        </div>
    </body>
    </html>
    """
    return HTMLResponse(content=html_content)

# Uvicorn launcher
if __name__ == "__main__":
    print("Starting FastAPI application...")
    uvicorn.run("main:app", host="0.0.0.0", port=settings.port, reload=True)
