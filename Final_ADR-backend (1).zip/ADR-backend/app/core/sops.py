from typing import Optional
from app.models.sop import SOPListResponse, SOPItem, Pagination
from app.dal.dynamo import fetch_sops

def get_sops_logic(
    abendType: Optional[str],
    jobName: Optional[str],
    search: Optional[str],
    next_token: Optional[str],
    limit: int
) -> SOPListResponse:
    start_key = {"sopID": next_token} if next_token else None

    items, next_eval_key = fetch_sops(
        abendType=abendType,
        jobName=jobName,
        search=search,
        limit=limit,
        start_key=start_key
    )

    sops = [SOPItem(**item) for item in items]

    pagination = Pagination(
        next=next_eval_key.get("sopID") if next_eval_key else None,
        hasMore=bool(next_eval_key),
        limit=limit
    )

    return SOPListResponse(sops=sops, pagination=pagination)
