import requests
from app.core.config import settings
from app.core.logger.struct_logger import logger


def call_gitlab(jobname, orderid, incnum, jobnodeid):  
    trigger_content = f"{jobname},{orderid},{incnum},{jobnodeid}"  
    data = {  
        'token': settings.gitlab_token,  
        'ref': settings.gitlab_ref_branch_name,  
        'variables[TRIGGER_CONTENT]': trigger_content  
    }  
    try:  
        response = requests.post(settings.gitlab_url, data=data, verify=False)  
        if response.ok:  
            logger.info("Pipeline triggered successfully with file content as a variable!")  
        else:  
            logger.error(f"Trigger failed: {response.status_code} - {response.text}")  
    except requests.exceptions.RequestException as e:  
        logger.exception(f"An error occurred while triggering the pipeline: {e}")  
