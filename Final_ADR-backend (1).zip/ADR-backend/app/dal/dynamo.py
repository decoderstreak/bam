import boto3
from boto3.dynamodb.conditions import Attr
from typing import Optional, Tuple, List
from datetime import datetime, timezone
from botocore.exceptions import ClientError
dynamodb = boto3.resource("dynamodb", region_name="us-east-2")
table = dynamodb.Table("adr-dynamodb-dev")  
#FIXME need to add the global seconday indexes by devops team
def get_total_abends_count() -> int:
    response = table.scan(
        Select="COUNT",
        FilterExpression=Attr("jobStatus").eq("Abended")
    )
    return response.get("Count", 0)
 
def count_abends_non_resolved() -> int:
    response = table.scan(
        Select="COUNT",
        FilterExpression=Attr("jobStatus").eq("Abended")
    )
    return response.get("Count", 0)
 
def count_abends_by_job_status() -> int:
    response = table.scan(
        Select="COUNT",
        FilterExpression=Attr("jobStatus").eq("Resolved")
    )
    return response.get("Count", 0)
 
def count_abends_assigned_to_ai() -> int:
    response = table.scan(
        Select="COUNT",
        FilterExpression=Attr("jobStatus").eq("Resolved") & Attr("assigned_to").eq("AI System")
    )
    return response.get("Count", 0)
 
def count_abends_assigned_to_humans() -> int:
    response = table.scan(
        Select="COUNT",
        FilterExpression=Attr("jobStatus").eq("Resolved") & Attr("assigned_to").ne("AI System")
    )
    return response.get("Count", 0)
    
#Insert record in the db
def insert_initial_abend(item: dict):
    timestamp = datetime.now(timezone.utc).isoformat()
    item["createdAt"] = timestamp
    item["updatedAt"] = timestamp
    item["createdBy"] = "system"
    item["updatedBy"] = "system"
    table.put_item(Item=item)

def fetch_abends(
    limit: int = 10,
    start_key: Optional[dict] = None,
    jobStatus: Optional[str] = None,
    domainArea: Optional[str] = None,
    severity: Optional[str] = None,
    abendedAt: Optional[str] = None,
    search: Optional[str] = None
) -> Tuple[List[dict], Optional[dict]]:
    filter_expr = None
    if jobStatus:
        filter_expr = Attr("jobStatus").eq(jobStatus)
    if domainArea:
        expr = Attr("domainArea").eq(domainArea)
        filter_expr = expr if not filter_expr else filter_expr & expr
    if severity:
        expr = Attr("severity").eq(severity)
        filter_expr = expr if not filter_expr else filter_expr & expr
    if abendedAt:
        expr = Attr("abendedAt").contains(abendedAt)
        filter_expr = expr if not filter_expr else filter_expr & expr
    if search:
        expr = Attr("jobName").contains(search) | Attr("abendedAt").contains(search)
        filter_expr = expr if not filter_expr else filter_expr & expr
    scan_kwargs = {"Limit": limit}
    if filter_expr:
        scan_kwargs["FilterExpression"] = filter_expr
    if start_key:
        scan_kwargs["ExclusiveStartKey"] = start_key
    response = table.scan(**scan_kwargs)
    return response.get("Items", []), response.get("LastEvaluatedKey")
#FIXME For this as the abend
def fetch_abend_by_job_id(job_id: str) -> Optional[dict]:
    try:
        response = table.scan(
            FilterExpression=Attr("jobId").eq(job_id)
        )
        items = response.get("Items", [])
        print(items)
        return items[0] if items else None
    except Exception as e:
        print("Scan error:", e)
        return None

def put_abend(item: dict):
    table.put_item(Item=item)


table1 = dynamodb.Table("SOPsTable")  

def fetch_sops(
    abendType: Optional[str],
    jobName: Optional[str],
    search: Optional[str],
    limit: int,
    start_key: Optional[dict]
) -> Tuple[List[dict], Optional[dict]]:
    filter_expr = None

    if abendType:
        filter_expr = Attr("abendType").contains(abendType)

    if jobName:
        job_expr = Attr("jobName").eq(jobName)
        filter_expr = job_expr if not filter_expr else filter_expr & job_expr

    if search:
        search_expr = Attr("jobName").contains(search)
        filter_expr = search_expr if not filter_expr else filter_expr & search_expr

    scan_kwargs = {"Limit": limit}
    if filter_expr:
        scan_kwargs["FilterExpression"] = filter_expr
    if start_key:
        scan_kwargs["ExclusiveStartKey"] = start_key

    response = table1.scan(**scan_kwargs)
    return response.get("Items", []), response.get("LastEvaluatedKey")
