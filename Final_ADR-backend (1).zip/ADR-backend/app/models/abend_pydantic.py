from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime, timezone

#Dropdown data model
class DropdownResponse(BaseModel):
    allStatus: List[str]
    allPrioriteies: List[str]
    allDomains: List[str]

class KnowledgeBaseFile(BaseModel):
    fileName: Optional[str] = ""
    fileType: Optional[str] = ""
    fileSize: Optional[int] = 0
    fileUrl: Optional[str] = ""

class EmailMetadata(BaseModel):
    subject: Optional[str]
    sentDateTime: Optional[str]
    receivedDateTime: Optional[str]
    hasAttachments: Optional[bool]
    isRead: Optional[bool]
    conversationID: Optional[str]

class AbendMetadata(BaseModel):
    abendedReturnCode: Optional[str]
    abendReason: Optional[str]
    abendType: Optional[str]

class LogExtractionMetadata(BaseModel):
    runID: Optional[str]
    retries: Optional[int]

class KnowledgeBaseMetadata(BaseModel):
    knowledgeBaseId: Optional[str]
    relevantSOPId: Optional[str]
    relevantSOPName: Optional[str]
    files: Optional[List[KnowledgeBaseFile]]

class RemediationMetadata(BaseModel):
    expandability: Optional[str]
    confidenceScore: Optional[float]
    remediationRecommendations: Optional[List[str]]
    aiRemediationApproval: Optional[str]
    aiRemediationComments: Optional[str]

class ExecutedRemediationAction(BaseModel):
    actionType: Optional[str]
    actionStatus: Optional[str]
    actionDateTime: Optional[str]
    actionComments: Optional[str]

class ResolutionVerification(BaseModel):
    resolutionType: Optional[str]
    resolutionStatus: Optional[str]
    resolutionDateTime: Optional[str]
    resolutionComments: Optional[str]
    executedRemediationActions: Optional[List[ExecutedRemediationAction]]

class AbendedJobExecutionMetadata(BaseModel):
    status: Optional[str]
    jobID: Optional[str]
    orderID: Optional[str]
    restartedAt: Optional[str]

class AbendItem(BaseModel):
    trackingID: str
    abendedAt: str
    jobID: Optional[str]
    jobName: str
    incidentNumber: str
    severity: str
    domainArea: str
    processStatus: str
    abendActionStatus: str
    orderID: Optional[str]
    faID: Optional[str]
    emailMetadata: Optional[EmailMetadata]
    abendMetadata: Optional[AbendMetadata]
    logExtractionMetadata: Optional[LogExtractionMetadata]
    knowledgeBaseMetadata: Optional[KnowledgeBaseMetadata]
    remediationMetadata: Optional[RemediationMetadata]
    resolutionVerification: Optional[ResolutionVerification]
    abendedJobExecutionMetadata: Optional[AbendedJobExecutionMetadata]
    createdAt: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updatedAt: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    createdBy: Optional[str]
    updatedBy: Optional[str]
    generation: Optional[int]


class Pagination(BaseModel):
    nextPageToken: Optional[str]
    hasMore: bool
    limit: int

class AbendsResponse(BaseModel):
    abends: List[AbendItem]
    pagination: Pagination
