from pydantic import BaseModel, Field
from datetime import datetime, timezone

class AuditLog(BaseModel):
    trackingId: str
    status: str
    level: str
    description: str
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))