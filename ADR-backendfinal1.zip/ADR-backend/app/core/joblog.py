import boto3
import io
from typing import Optional
from app.core.logger.struct_logger import logger
from botocore.exceptions import ClientError 
class DynamoDBJobLog:
    def __init__(self, table_name: str):
        self.table_name = table_name

    def get_job_log(self, tracking_id: str) -> Optional[str]:
        """
        Retrieves the content of a file from an S3 bucket by matching its name with the tracking ID.

        :param bucket_name: Name of the S3 bucket
        :param tracking_id: Unique tracking ID to locate the file
        :return: String content of the file if found, else None
        """
        try:
            s3 = boto3.client('s3')
            response = s3.list_objects_v2(Bucket='adr-abend-log-in-dev', Prefix='inbound/')

            if 'Contents' in response:
                for obj in response['Contents']:
                    file_name = obj['Key']

                    if tracking_id in file_name:
                        file_obj = io.BytesIO()
                        s3.download_fileobj('adr-abend-log-in-dev', file_name, file_obj)
                        file_obj.seek(0)

                        logger.info(f"Downloaded {file_name} into memory.")

                        file_content = file_obj.read().decode('utf-8')
                        return file_content

            logger.warning("File with the given tracking ID not found.")
            return None

        except ClientError as e:
            logger.exception("AWS S3 client error occurred", error=str(e))
            return None
        except Exception as ex:
            logger.exception("Unexpected error while retrieving job log", error=str(ex))
            return None 