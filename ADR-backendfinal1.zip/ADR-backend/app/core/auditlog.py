from typing import Dict
from pydantic import ValidationError
from app.core.logger.struct_logger import logger
from app.utils.DynamoDBHelper import insert_into_dynamodb
from botocore.exceptions import ClientError 
from app.models.auditlog_pydantic import AuditLog
from typing import Optional

class DynamoDBAuditLog:
    def __init__(self, table_name: str):
        self.table_name = table_name

    def log_audit_record(self, record: Dict) -> bool:
        """
        Validates and attempts to save an audit record to DynamoDB.

        :param record: Dictionary containing audit log fields
        :return: Boolean indicating success or failure of the operation
        """
        try:
            # Validate the input record using AuditLog model
            audit_log = AuditLog(**record)
            logger.info("Audit log validated successfully", audit_log=audit_log.model_dump())

            # Insert into DynamoDB
            response = insert_into_dynamodb(self.table_name, audit_log.model_dump())
            if response:
                logger.info("Audit log item saved successfully", record=record)
                return True
            else:
                logger.error("Failed to save audit log item", record=record)
                return False

        except ValidationError as e:
            logger.error("Validation error in audit log record", errors=e.errors())
            return False

        except Exception as e:
            logger.exception("An error occurred while logging the audit record", error=str(e))
            return False
    #FIXME -> Added the get audit record code
    
    def get_audit_record(self, tracking_id: str) -> Optional[Dict]:
        """
        Retrieves a specific audit record by its primary key.

        :param record_id: The primary key (or partition key) of the audit log entry
        :return: The record if found, else None
        """
        try:
            response = self.table.get_item(Key={"trackingID": tracking_id})
            if 'Item' in response:  
                logger.info("Audit record retrieved successfully", tracking_id=tracking_id)  
                return response.get('Item') #FIXME fixed
            else:  
                logger.warning("Audit log record not found", tracking_id=tracking_id)  
                return None   
        except ClientError as e:  
            logger.error(f"Failed to retrieve abend record {tracking_id}: {e}")  
            return None 
        
    