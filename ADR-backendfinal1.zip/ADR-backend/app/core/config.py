import os
import sys
from dotenv import load_dotenv
from app.constant import constants
from app.core.logger.struct_logger import logger
from app.utils.SecretHelper import get_secret

load_dotenv()

class Settings:
    APP_NAME: str = "adr"
    APP_SERVICE_NAME: str = "adr-svc"

    def __init__(self):
        try:
            self.load_secrets()
        except Exception as e:
            logger.exception("Failed to load secrets.", exc_info=e)
            sys.exit(1)

    def get_env(self, var_name, default=None):
        """Utility method for fetching environment variables."""
        return os.getenv(var_name, default)

    def secret_name(self):
        region = self.get_env("REGION")
        return (
            f"adr-{region}-graphapi-secret",
            f"adr-{region}-gitlab-secrets",
            f"adr-{region}-dynamodb-secrets"
        )

    def load_secrets(self):
        if self.is_dev_env == "local":
            self.load_secrets_from_env()
        elif self.is_dev_env == "dev":
            self.load_secrets_from_aws()

    def load_secrets_from_aws(self):
        try:
            secrets = self.secret_name()
            self._adr_graphapi_secrets = get_secret(secrets[0])
            self._adr_gitlab_secrets = get_secret(secrets[1])
            self._adr_dynamodb_secrets = get_secret(secrets[2])
            logger.info("Successfully loaded secrets from AWS.")
        except Exception as e:
            logger.error("Failed to load secrets from AWS.", exc_info=e)
            self._adr_graphapi_secrets = {}
            self._adr_gitlab_secrets = {}
            self._adr_dynamodb_secrets = {}

    def load_secrets_from_env(self):
        logger.info("Loading secrets from environment variables.")
        self._adr_graphapi_secrets = {
            "ADR-ClientId": self.get_env("ADR-ClientId"),
            "ADR-ClientSecret": self.get_env("ADR-ClientSecret"),
            "ADR-TenantId": self.get_env("ADR-TenantId"),
            "ADR-UserEmail": self.get_env("ADR-UserEmail"),
        }
        self._adr_gitlab_secrets = {
            "ADR-GitlabUrl": self.get_env("ADR-GitlabUrl"),
            "ADR-GitlabToken": self.get_env("ADR-GitlabToken"),
            "ADR-GitlabBranchName": self.get_env("ADR-GitlabBranchName"),
        }
        self._adr_dynamodb_secrets = {
            "BUCKET_NAME": self.get_env("BUCKET_NAME"),
            "DYNAMO_ABEND_TABLE_NAME": self.get_env("DYNAMO_ABEND_TABLE_NAME"),
            "DYNAMO_AUDITLOG_TABLE_NAME": self.get_env("DYNAMO_AUDITLOG_TABLE_NAME"),
        }

    @property
    def is_dev_env(self):
        return self.get_env("ENV")

    @property
    def log_level(self):
        return "DEBUG" if self.is_dev_env else "INFO"

    @property
    def port(self):
        return 8002

    def get_constant(self, constant_name):
        """Utility method for fetching constants."""
        return getattr(constants, constant_name, None)

    @property
    def microsoft_authority(self):
        return self.get_constant("MICROSOFT_AUTHORITY")

    @property
    def valid_email_senders(self):
        return self.get_constant("VALID_EMAIL_SENDER")

    @property
    def microsoft_mark_email_read_url(self):
        return self.get_constant("MICROSOFT_MARK_EMAIL_READ_URL")

    @property
    def microsoft_email_pooling(self):
        return self.get_constant("MICROSOFT_EMAIL_POOLING")

    @property
    def microsoft_email_body(self):
        return self.get_constant("MICROSOFT_EMAIL_BODY")

    @property
    def microsoft_attachment(self):
        return self.get_constant("MICROSOFT_ATTACHMENT")

    @property
    def microsoft_scopes(self):
        return self.get_constant("MICROSOFT_SCOPES")

    @property
    def gitlab_url(self):
        return self._adr_gitlab_secrets.get("ADR-GitlabUrl", "")

    @property
    def gitlab_token(self):
        return self._adr_gitlab_secrets.get("ADR-GitlabToken", "")

    @property
    def gitlab_ref_branch_name(self):
        return self._adr_gitlab_secrets.get("ADR-GitlabBranchName", "")

    @property
    def client_id(self):
        return self._adr_graphapi_secrets.get("ADR-ClientId", "")

    @property
    def client_secret(self):
        return self._adr_graphapi_secrets.get("ADR-ClientSecret", "")

    @property
    def tenant_id(self):
        return self._adr_graphapi_secrets.get("ADR-TenantId", "")

    @property
    def user_email(self):
        return self._adr_graphapi_secrets.get("ADR-UserEmail", "")

    @property
    def bucket_name(self):
        return self._adr_dynamodb_secrets.get("BUCKET_NAME", "")

    @property
    def dynamo_abend_table_name(self):
        return self._adr_dynamodb_secrets.get("DYNAMO_ABEND_TABLE_NAME", "")

    @property
    def dynamo_auditlog_table_name(self):
        return self._adr_dynamodb_secrets.get("DYNAMO_AUDITLOG_TABLE_NAME", "")
    
try:
    settings = Settings()
except Exception as e:
    logger.exception("Failed to load application configuration.", exc_info=e)
    sys.exit(1)
