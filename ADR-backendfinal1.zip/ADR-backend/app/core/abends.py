import boto3
from boto3.dynamodb.conditions import Key , Attr
from typing import Dict, Optional, List
from pydantic import ValidationError
from botocore.exceptions import ClientError  
from app.core.logger.struct_logger import logger
from app.utils.DynamoDBHelper import insert_into_dynamodb, update_dynamodb_item
from app.models.abend_pydantic import AbendItem

class DynamoDBAbend:
    def __init__(self, table_name: str):
        self.table_name = table_name
        self.dynamodb = boto3.resource('dynamodb')
        self.table = self.dynamodb.Table(table_name)

    def save_abend_record(self, record: Dict) -> bool:
        try:
            abend_item = AbendItem(**record)
            logger.info("Abend record validated successfully", abend_item=abend_item.model_dump())
            response = insert_into_dynamodb(self.table_name, abend_item.model_dump())
            if response:
                logger.info("Abend record item saved successfully", record=record)
                return True
            else:
                logger.error("Failed to save abend record item", record=record)
                return False
        except ValidationError as e:
            logger.error("Validation error in abend record", errors=e.errors())
            return False
        except Exception as e:
            logger.exception("An error occurred while logging the abend record", error=str(e))
            return False

    def update_abend_record(self, tracking_id: str, new_process_status: str) -> bool:
        try:
            key = {'trackingID': tracking_id}
            update_expression = 'SET processStatus = :ps, generation = generation + :inc'
            expression_attribute_values = {
                ':ps': new_process_status,
                ':inc': 1
            }
            response = update_dynamodb_item(self.table_name, key, update_expression, expression_attribute_values)
            if response:
                logger.info("Abend record updated successfully", tracking_id=tracking_id)
                return True
            else:
                logger.error("Failed to update abend record", tracking_id=tracking_id)
                return False
        except Exception as e:
            logger.exception("An error occurred while updating the abend record", error=str(e))
            return False

    def get_abend_record(self, tracking_id: str) -> Optional[Dict]:  
        try:  
            response = self.table.get_item(Key={'trackingID': tracking_id})  
            if 'Item' in response:  
                logger.info("Abend record retrieved successfully", tracking_id=tracking_id)  
                return response['Item']  
            else:  
                logger.warning("Abend record not found", tracking_id=tracking_id)  
                return None  
        except ClientError as e:  
            logger.error(f"Failed to retrieve abend record {tracking_id}: {e}")  
            return None  

    def list_abends(
        self,
        limit: int,
        nextPageToken: Optional[str] = None,
        jobStatus: Optional[str] = None,
        domainArea: Optional[str] = None,
        severity: Optional[str] = None,
        abendedAt: Optional[str] = None,
        search: Optional[str] = None
    ) -> List[Dict]:
        try:
            filters = []
            if jobStatus:
                filters.append(Key('jobStatus').eq(jobStatus))
            if domainArea:
                filters.append(Key('domainArea').eq(domainArea))
            if severity:
                filters.append(Key('severity').eq(severity))
            if abendedAt:
                filters.append(Key('abendedAt').eq(abendedAt))
                
            filter_expression = None
            if filters:
                filter_expression = filters[0]
                for f in filters[1:]:
                    filter_expression &= f

            scan_params = {'Limit': limit}
            if filter_expression:
                scan_params['FilterExpression'] = filter_expression
            if nextPageToken:
                scan_params['ExclusiveStartKey'] = {'id': nextPageToken}

            response = self.table.scan(**scan_params)
            logger.info(f"Successfully retrieved abends with filters: {scan_params}")
            return response.get('Items', [])

        except ClientError as e:
            logger.error(f"Error querying abends: {e}")
            return []

class AbendMetrics:
    def __init__(self, table_name: str):
        self.dynamodb = boto3.resource('dynamodb')
        self.table = self.dynamodb.Table(table_name)

    async def get_total_abends_count(self) -> int:
        return await self._count_by_filter(Attr("jobStatus").exists())

    async def count_abends_non_resolved(self) -> int:
        return await self._count_by_filter(Attr("jobStatus").eq("Abended"))

    async def count_abends_by_job_status(self) -> int:
        return await self._count_by_filter(Attr("jobStatus").eq("Resolved"))

    async def count_abends_assigned_to_ai(self) -> int:
        return await self._count_by_filter(Attr("jobStatus").eq("Resolved") & Attr("assigned_to").eq("AI System"))

    async def count_abends_assigned_to_humans(self) -> int:
        return await self._count_by_filter(Attr("jobStatus").eq("Resolved") & Attr("assigned_to").ne("AI System"))

    async def _count_by_filter(self, filter_expression) -> int:
        try:
            response = self.table.scan(
                Select="COUNT",
                FilterExpression=filter_expression
            )
            return response.get("Count", 0)
        except ClientError as e:
            logger.error(f"Error counting abends: {e}")
            return 0
