import os
import tempfile
from app.utils.AwsHelper import AWSS3Helper
from app.core.logger.struct_logger import logger
import requests
def extract_data_source_lines(lines, start_idx):
    data_lines = []
    for idx in range(start_idx, len(lines)):
        line = lines[idx]
        if line.strip().startswith('WORKING-STORAGE SECTION') or line.strip().startswith('LINKAGE SECTION') or "See \"System-Wide Information\"" in line:
            break
        if len(line) >= 42:
            data_part = line[41:]
            data_lines.append(data_part)
    return data_lines, idx


def split_file(filepath, tracking_id, bucket):
    with open(filepath, 'r') as f:
        lines = f.readlines()

    part1, part2, part3 = [], [], []
    stage = 1
    i = 0
    while i < len(lines):
        line = lines[i]

        if stage == 1:
            part1.append(line)
            if "IBM Fault Analyzer" in line:
                stage = 2

        elif stage == 2:
            if "<H" in line and "S Y N O P S I S" in line:
                part2.append(line)
                i += 1
                while i < len(lines) and not ("<H" in lines[i] or 'E V E N T   S U M M A R Y' in lines[i]):
                    part2.append(lines[i])
                    i += 1
                continue

            if "P O I N T   O F   F A I L U R E" in line:
                part2.append(line)
                i += 1
                while i < len(lines) and "Load Module Name." not in lines[i]:
                    part2.append(lines[i])
                    i += 1
                continue

            if line.strip().startswith("FILE SECTION"):
                part2.append(line)
                i += 1
                data_block, i = extract_data_source_lines(lines, i)
                part2.extend(data_block)
                continue

            if line.strip().startswith("WORKING-STORAGE SECTION"):
                part2.append(line)
                i += 1
                data_block, i = extract_data_source_lines(lines, i)
                part2.extend(data_block)
                continue

            if line.strip().startswith("LINKAGE SECTION"):
                part2.append(line)
                i += 1
                data_block, i = extract_data_source_lines(lines, i)
                part2.extend(data_block)
                continue

            if "See \"System-Wide Information\"" in line:
                part2.append(line)
                stage = 3

        elif stage == 3:
            if "<H" in line and "S Y S T E M - W I D E   I N F O R M A T I O N" in line:
                part3.append(line)
                i += 1
                while i < len(lines):
                    part3.append(lines[i])
                    if "End of Fault Analyzer report" in lines[i]:
                        break
                    i += 1
                break
        i += 1

    # Extract tokens from filename
    #FIXME -> Have proper names
    tokens = filepath.replace('.txt', '').split('_')
    _, _, jobname, orderid, incnum, trackingid, datetime = tokens

    # Create temp files with meaningful names
    with tempfile.NamedTemporaryFile(delete=False, mode='w', suffix=".txt", prefix=f"ADR_CMODLOG_{jobname}_{orderid}_{incnum}_{trackingid}_{datetime}") as f1, \
         tempfile.NamedTemporaryFile(delete=False, mode='w', suffix=".txt", prefix=f"ADR_FALOG1_{jobname}_{orderid}_{incnum}_{trackingid}_{datetime}") as f2, \
         tempfile.NamedTemporaryFile(delete=False, mode='w', suffix=".txt", prefix=f"ADR_FALOG2_{jobname}_{orderid}_{incnum}_{trackingid}_{datetime}") as f3:
        
        f1.writelines(part1)
        f2.writelines(part2)
        f3.writelines(part3)

        fname1 = os.path.abspath(f1.name)
        fname2 = os.path.abspath(f2.name)
        fname3 = os.path.abspath(f3.name)

    logger.info("Files created", files={"file1": fname1, "file2": fname2, "file3": fname3})

    AWSS3Helper.upload_file_to_s3(fname1, bucket, os.path.basename(fname1))
    AWSS3Helper.upload_file_to_s3(fname2, bucket, os.path.basename(fname2))
    AWSS3Helper.upload_file_to_s3(fname3, bucket, os.path.basename(fname3))
    #combined = "".join([*part1, *part2, *part3])
    