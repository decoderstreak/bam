import boto3
import json
from botocore.exceptions import ClientError
from app.core.logger.struct_logger import logger

def get_secret(secret_name):
    """
    Fetch secret from AWS Secrets Manager.

    :param secret_name: Name of the secret
    :return: Secret value as a dictionary
    """
    session = boto3.session.Session()
    client = session.client(service_name='secretsmanager')

    try:
        get_secret_value_response = client.get_secret_value(SecretId=secret_name)
        
        # Check if secret is present as a string or binary
        if 'SecretString' in get_secret_value_response:
            secret = get_secret_value_response['SecretString']
            return json.loads(secret)
        else:
            logger.error("Secret not available as a string.")
            return None
    except ClientError as e:
        logger.error(f"Error fetching secret {secret_name}: {e}")
        return None
