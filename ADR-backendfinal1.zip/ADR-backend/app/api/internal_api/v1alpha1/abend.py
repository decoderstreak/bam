from fastapi import APIRouter, HTTPException, Body, Query
from datetime import datetime, timezone
from app.models.abend_pydantic import AbendItem
from app.models.auditlog_pydantic import AuditLog
from app.core.abends import DynamoDBAbend
from app.utils.DynamoDBHelper import insert_into_dynamodb
import boto3
import tempfile
from app.core.logger.struct_logger import logger
from app.utils.FileSplit import split_file 
from app.core.config import settings
import os

router = APIRouter()

@router.post(
    "/logfile",
    summary="Process and split a log file from S3",
    description="""
Retrieves a specified log file from an S3 bucket, processes its contents,
splits the file into structured parts, and uploads the resulting files back to S3.

- **tracking_id**: A unique ID used for tracking the request.
- **filename**: The exact name of the log file stored in the S3 bucket.
"""
)
async def get_logfile(
    tracking_id: str = Query(...),
    filename: str = Query(...)
):
    bucket_name = settings.bucket_name
    s3 = boto3.client("s3")

    logger.info(f"Received request to process file: {filename} with tracking_id: {tracking_id}")
    
    try:
        with tempfile.NamedTemporaryFile(mode='wb+', delete=False) as tmp_fp:
            temp_path = tmp_fp.name
            logger.info(f"Using temp file: {temp_path}")
            s3.download_file(bucket_name, filename, temp_path)
    except Exception as e:
        logger.error(f"Error during S3/download: {e}")
        return {"error": "Downloading failed", "details": str(e)}
            
    try:
        logger.info("Splitting and uploading file to S3...")
        dynamo_abend = DynamoDBAbend(table_name=settings.dynamo_abend_table_name)
        dynamo_abend.update_abend_record(tracking_id, "LOG_EXTRACTION_INITIATED")
            
            # Create an audit log entry
        audit_log_entry = {
            "trackingId": tracking_id,
                "status": "LOG_EXTRACTION_INITIATED",
                "level": "INFO",
                "description": "Log extraction initiated and getting processed",
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        audit_log = AuditLog(**audit_log_entry)
        insert_into_dynamodb(settings.dynamo_auditlog_table_name, audit_log.model_dump())
        split_file(filepath=temp_path, tracking_id=tracking_id, bucket=bucket_name)
        dynamo_abend = DynamoDBAbend(table_name=settings.dynamo_abend_table_name)
        dynamo_abend.update_abend_record(tracking_id, "LOG_UPLOAD_TO_S3")
            
            # Create an audit log entry
        audit_log_entry = {
            "trackingId": tracking_id,
                "status": "LOG_UPLOAD_TO_S3",
                "level": "INFO",
                "description": "Log is uploaded to s3",
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        audit_log = AuditLog(**audit_log_entry)
        insert_into_dynamodb(settings.dynamo_auditlog_table_name, audit_log.model_dump())
        os.remove(temp_path)
    except Exception as e:
        logger.error(f"Failed during split/upload process: {e}")
        return {"error": "Split/upload failed", "details": str(e)}

    logger.info(f"Completed processing for tracking_id: {tracking_id}")
    return {
        "message": "Files processed and uploaded to S3",
        "tracking_id": tracking_id,
        "filename": filename
    }

@router.post("/abends", response_model=AbendItem)
def create_abend(abend: AbendItem = Body(...)):
    """
    Endpoint to create an abend record in DynamoDB.

    :param abend: AbendItem model data
    :return: Saved abend item
    """
    try:
        dynamo_abend = DynamoDBAbend(table_name="adr-abend-dynamodb-dev")
        if dynamo_abend.save_abend_record(abend.model_dump()):
            # Update the processStatus to ABEND_REGISTERED
            dynamo_abend.update_abend_record(abend.trackingID, "ABEND_REGISTERED")
            
            # Create an audit log entry
            audit_log_entry = {
                "trackingId": abend.trackingID,
                "status": "ABEND_REGISTERED",
                "level": "INFO",
                "description": "Abend notification received and processed",
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
            audit_log = AuditLog(**audit_log_entry)
            insert_into_dynamodb("adr-auditlog-dynamodb-dev", audit_log.model_dump())
            
            return abend
        else:
            raise HTTPException(
                status_code=500,
                detail={
                    "code": "INTERNAL_ERROR",
                    "message": "Failed to save abend record",
                }
            )
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail={
                "code": "INTERNAL_ERROR",
                "message": "Failed to save abend record",
                "details": str(e),
            }
        )
