"""
Utility file containing API constants
"""

ABEND_API_GROUP = "abend"
SOP_API_GROUP = "sop"

