from fastapi import APIRouter, HTTPException
from app.models.abend_pydantic import AbendItem
from app.core.joblog import DynamoDBJobLog
import json
router = APIRouter()

#FIXME -> Get the joblog for the tracking id
@router.get("/joblog/{tracking_id}", response_model=AbendItem)
async def get_abend_logfile_by_tracking_id(tracking_id: str):
    try:
        dynamo_abend_log = DynamoDBJobLog(table_name="adr-abend-dynamodb-dev")
        abendlog = dynamo_abend_log.get_job_log(tracking_id)
        
        if not abendlog:
            raise HTTPException(
                status_code=404,
                detail=f"No abend found for tracking ID: {tracking_id}"
            )
    
        abendlog_dict = json.loads(abendlog)

        return AbendItem(**abendlog_dict)

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail={
                "code": "INTERNAL_ERROR",
                "message": "Failed to fetch abendlog",
                "details": str(e),
            }
        )