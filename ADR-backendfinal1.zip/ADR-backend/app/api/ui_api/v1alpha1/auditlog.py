from fastapi import APIRouter, HTTPException
from app.models.auditlog_pydantic import AuditLog
from app.core.auditlog import DynamoDBAuditLog 
router = APIRouter()

#FIXME -> Added api call for audit log -> check for this
@router.get("/auditlog/tracking/{tracking_id}", response_model=AuditLog)
async def get_abend_details_by_tracking_id(tracking_id: str):
    try:
        dynamo_abend = DynamoDBAuditLog(table_name="adr-abend-dynamodb-dev")#FIXME -> get from .env
        auditlog = dynamo_abend.get_audit_record(tracking_id) 
        if not auditlog:
            raise HTTPException(
                status_code=404,
                detail=f"No audit log found for tracking ID: {tracking_id}"
            )
        return AuditLog(**auditlog)
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail={
                "code": "INTERNAL_ERROR",
                "message": "Failed to fetch audit log",
                "details": str(e),
            }
        )