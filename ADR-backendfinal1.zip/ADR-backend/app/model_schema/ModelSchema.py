AbendTableName = "adr-abend-dynamodb-dev"
AbendKeySchema = [
    {
        'AttributeName': 'trackingID',
        'KeyType': 'HASH'  # Partition key
    },
    {
        'AttributeName': 'abendedAt',
        'KeyType': 'RANGE'  # Sort key
    }
]

AbendAttributeDefinitions = [
    {'AttributeName': 'trackingID', 'AttributeType': 'S'},
    {'AttributeName': 'abendedAt', 'AttributeType': 'S'},
    {'AttributeName': 'abendType', 'AttributeType': 'S'},
    {'AttributeName': 'jobName', 'AttributeType': 'S'},
    {'AttributeName': 'domainArea', 'AttributeType': 'S'},
    {'AttributeName': 'abendActionStatus', 'AttributeType': 'S'},
]

# Define the global secondary indexes
AbendGlobalSecondaryIndexes = [
    {
        'IndexName': 'AbendTypeIndex',
        'KeySchema': [
            {'AttributeName': 'abendType', 'KeyType': 'HASH'},
            {'AttributeName': 'abendedAt', 'KeyType': 'RANGE'}
        ],
        'Projection': {'ProjectionType': 'ALL'},
        'ProvisionedThroughput': {'ReadCapacityUnits': 5, 'WriteCapacityUnits': 5}
    },
    {
        'IndexName': 'JobNameIndex',
        'KeySchema': [
            {'AttributeName': 'jobName', 'KeyType': 'HASH'},
            {'AttributeName': 'abendedAt', 'KeyType': 'RANGE'}
        ],
        'Projection': {'ProjectionType': 'ALL'},
        'ProvisionedThroughput': {'ReadCapacityUnits': 5, 'WriteCapacityUnits': 5}
    },
    {
        'IndexName': 'DomainAreaIndex',
        'KeySchema': [
            {'AttributeName': 'domainArea', 'KeyType': 'HASH'},
            {'AttributeName': 'abendedAt', 'KeyType': 'RANGE'}
        ],
        'Projection': {'ProjectionType': 'ALL'},
        'ProvisionedThroughput': {'ReadCapacityUnits': 5, 'WriteCapacityUnits': 5}
    },
    {
        'IndexName': 'AbendActionStatusIndex',
        'KeySchema': [
            {'AttributeName': 'abendActionStatus', 'KeyType': 'HASH'},
            {'AttributeName': 'abendedAt', 'KeyType': 'RANGE'}
        ],
        'Projection': {'ProjectionType': 'ALL'},
        'ProvisionedThroughput': {'ReadCapacityUnits': 5, 'WriteCapacityUnits': 5}
    },
]

AuditTableName = "adr-auditlog-dynamodb-dev"
AuditLogKeySchema = [  
        {  
            'AttributeName': 'trackingId',  
            'KeyType': 'HASH'  # Partition key  
        }  
    ]  
  
AuditAttributeDefinitions = [  
        {'AttributeName': 'trackingId', 'AttributeType': 'S'},  
        {'AttributeName': 'status', 'AttributeType': 'S'},  
        {'AttributeName': 'level', 'AttributeType': 'S'},  
        {'AttributeName': 'description', 'AttributeType': 'S'},  
        {'AttributeName': 'timestamp', 'AttributeType': 'S'},  
    ]  
  